(function($) {
    "use strict";
    var $win, timer, $item, $this, $popupOverlay, $popupClose, $btnSocial, $btnArea, $btnA, $btnSecond, $midHeight, $oneContents, $secondContents, $selectTitle, $externalPopup, $nosizePopup, oneHeight, secondHeight, rows = 3,
        itemLen = 0;
        

    function init(){
      slider();
    }

    function slider() {
        var listLen = $('.bxslider').find("li").length;
        var slider = $(".bxslider").bxSlider({
            maxSlides: listLen,
            speed: 600,
            slideMargin: 50,
            auto: true,
            onSliderLoad: function() {
              var addCurrentClass = listLen + 'n+1';
              console.log(addCurrentClass);
              $('.bxslider').find("li").css('margin-right','50px');
              $('.bxslider').find('li:nth-child(' + addCurrentClass + ')').addClass('current');
              $('.bxslider').find('.current').prev().css('margin-right','200px');
            },
            onSlideBefore: function() {
              $('.bxslider').find("li").css('margin-right','50px');
              $('.bxslider').find("li").removeClass('current');
              $('.bxslider').find("li").removeClass('pre-current');
              slider.startAuto();
              var current = slider.getCurrentSlide();
              var addCurrentClass = listLen + 'n+' + (current + 1);

              $('.bxslider').find("li").removeClass('current');
              $('.bxslider').find("li").removeClass('pre-current');
              $('.bxslider').find('li:nth-child(' + addCurrentClass + ')').addClass('current');
              $('.bxslider').find('.current').prev().addClass('pre-current').css('margin-right','200px');
            },
            onSlideAfter: function() {
            }
        });
    }

    $(function() {
        init();
    });
})(jQuery);